



<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right">
	<div class="container">
	
		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
		&copy Copyright 2017 project worlds developed by <a href="http://projectworlds.in/contacts-us">Yugesh Verma <a/>
	</div>
</div>