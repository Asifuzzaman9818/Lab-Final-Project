# Tours-and-travels-in-php
Online Tours &amp; Travels management system: This is an online project developed using PHP and MySQL.  The purpose of this project is to provide the complete information about the vehicles available for a tour.  There are 2 different types of users. First the customer visits the site and enters the place from where to where he wishes to travel.  He also provides the date as when he would like to travel.  Then he sends these details to the travel and tourism agency. The employee of travel and tourism agency receives the mail and check which vehicle is available for that day and reverts back to the customer along with the quotation.  If the customer agrees for any one of the quotation, he can reply back along with agreed quotation.
Online Tours & Travels management system: This is an online project developed using PHP and MySQL.

The purpose of this project is to provide the complete information about the vehicles available for a tour.

There are 2 different types of users. First the customer visits the site and enters the place from where to where he wishes to travel.

He also provides the date as when he would like to travel.

Then he sends these details to the travel and tourism agency. The employee of travel and tourism agency receives the mail and check which vehicle is available for that day and reverts back to the customer along with the quotation.

If the customer agrees for any one of the quotation, he can reply back along with agreed quotation.

Objective Of the Project
Faster processing time and more accurate data for travel requests and reimbursements
Ability for travelers to track authorization and reimbursement request status through the system rather than via phone calls or campus mail
Major technological upgrades to the current travel system
Use of IU’s standardized, virtual J2EE environments
Many new features and enhancements
Software Requirements
WAMP Server
XAMPP Server
Installation/Configuration Steps
Download zip files and Unzip files.
Copy and Paste the unzip files inside “c:/wamp/www/” or “c:/xampp/htdocs/”.
Database Configuration:
Create a new database named “db name”.
Import database travel.sql file through phpmyadmin dashboard
Run/Execute PHP Projects
Open Your Web Browser
Put/type inside the web browser : “localhost/project folder”
Admin Login
Open Your Web Browser
Put/type inside the web browser : “localhost/project folder/Admin”
Admin User : admin
Admin Password : admin
